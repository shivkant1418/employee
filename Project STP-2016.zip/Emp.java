import javax.swing.JOptionPane;
import java.io.*;
import java.util.*;
class employee
			{
				static Properties p=new Properties();
						static String uname="";
						static String uid="";
						static String upin="";
						static String doj="";
						static String pfn="";
						static String bp="";
						static String pn="";
						static String fp="";
						static String fb="";
			public static void main(String ...ar)
					{
					Scanner sc=new Scanner(System.in);
					System.out.println("\t \t \t \t \t \t \t \t \t             WELCOME TO THE COMPUTER WORLD \t \t \t \t \t \t \t \t \t \t \t \t \t ");
					System.out.println("Choose Your Option:-");
					System.out.println("1.SIGN UP");
					System.out.println("2.SIGN IN");
					System.out.println("3.FORGOT USERPIN");
					int choose=sc.nextInt();
					switch(choose)
									{
									case 1: signup();
											break;
									case 2: signin();
											break;
									case 3: forgot();
											break;
									default:
											String sk1="PLEASE CHOOSE CORRECT OPTION";
														JOptionPane.showMessageDialog(null,sk1);
											System.exit(0);
									}
					System.out.println("\t \t \t \t \t \t \t \t \t             CHOOSE YOUR OPTION \t \t \t \t \t \t \t \t \t \t \t \t \t ");
					System.out.println();
					System.out.println("\t \t \t \t \t \t \t \t \t            1.EMPLOYEE PAY-SLIP \t \t \t \t \t \t \t \t \t \t \t \t \t ");
					System.out.println();
					System.out.println("\t \t \t \t \t \t \t \t \t            2.APPLY FOR LEAVE            \t \t \t \t \t \t \t \t \t \t \t \t \t ");	
					System.out.println();					
					System.out.println("\t \t \t \t \t \t \t \t \t            3.CLIENT RECORD     \t \t \t \t \t \t \t \t \t \t \t \t \t ");
					System.out.println();
					System.out.println("\t \t \t \t \t \t \t \t \t            4.ONGOING PROJECTS  \t \t \t \t \t \t \t \t \t \t \t \t \t ");
					System.out.println();
					System.out.println("\t \t \t \t \t \t  	 			    5.PERSONAL INFO.	  \t \t \t \t \t \t \t \t \t \t \t \t \t ");
					System.out.println();
					int b=sc.nextInt();
					switch(b)
								{
								case 1: Employee_Payslip();
										break;
								case 2: Apply_For_Leave();
										break;
								case 3: System.out.println();
										System.out.println();
										System.out.println();
										System.out.println("\t \t \t \t \t \t  	 			   WELCOME TO CLIENT RECORD	  \t \t \t \t \t \t \t \t \t \t \t \t \t ");
										System.out.println("1.ADD CLIENT");
										System.out.println("2.VIEW CLIENT");
										System.out.println("3.UPDATE CLIENT INFORMATION");
										System.out.println("4.DELETE CLIENT");
										int r=sc.nextInt();
										if(r==1)
										{
										ADD_CLIENT();	
										}
										else
										{
											if(r==2)
											{
												VIEW_CLIENT();
											}
											else
											{
												if(r==3)
												{
													UPDATE_CLIENT();
												}
												else
												{
													if(r==4)
													{
														DELETE_CLIENT();
													}
													else
													{
														String sk0="WRONG INPUT";
														JOptionPane.showMessageDialog(null,sk0);
													}
												}
											}
										}
										
										break;
								case 4: System.out.println();
										System.out.println();
										System.out.println();
										System.out.println("\t \t \t \t \t \t  	 			   WELCOME TO CLIENT RECORD	  \t \t \t \t \t \t \t \t \t \t \t \t \t ");
										System.out.println("1.ADD PROJECT");
										System.out.println("2.VIEW PROJECT");
										System.out.println("3.DELETE PROJECT");
										int hp=sc.nextInt();
										if(hp==1)
										{
										ADD_Projects();	
										}
										else
										{
											if(hp==2)
											{
												VIEW_PROJECT();
											}
											else
											{
												if(hp==3)
												{
													DELETE_PROJECT();
												}
												else
												{
												String sk2="WRONG INPUT";
														JOptionPane.showMessageDialog(null,sk2);	
												System.exit(0);
												}
												}
										}
										
										break;
								case 5: System.out.println();
										System.out.println();
										System.out.println("\t \t \t \t \t \t  	 			   WELCOME TO CLIENT RECORD	  \t \t \t \t \t \t \t \t \t \t \t \t \t ");
										System.out.println("1.UPDATE PROFILE");
										System.out.println("2.CHANGE PIN");
										int up=sc.nextInt();
										if(up==1)
										{
										UPDATE_Profile();	
										}
										else
										{
											if(up==2)
											{
												Change_PIN();
											}
											else
											{
												String sk3="WRONG INPUT";
														JOptionPane.showMessageDialog(null,sk3);	
												System.exit(0);
											}
										}
										break;
								default:
										String sk4="PLEASE CHOOSE CORRECT OPTION";
														JOptionPane.showMessageDialog(null,sk4);	
														System.exit(0);
								}
							
					}
					
					static void UPDATE_Profile()
					{
					System.out.println("\t \t \t \t \t \t \t \t \t            WELCOME"+"\t"+uid+" \t \t \t \t \t \t \t \t \t \t \t \t \t ");
								System.out.println();
								System.out.println();
								System.out.println("\t \t \t \t \t \t \t \t \t            NAME"+"\t"+p.getProperty("USERNAME")+" \t \t \t \t \t \t \t \t \t \t \t \t \t ");
								System.out.println();	
					try
						{
						System.out.println();
						Scanner up=new Scanner(System.in);
						System.out.println();
						System.out.print("Enter your Full Name:");
						uname=up.nextLine();
						System.out.println();
						System.out.print("Please Enter your Date of Joining:");
						doj=up.nextLine();
						System.out.println();
						System.out.print("Please Enter Your Pf No.:");
						pfn=up.nextLine();
						System.out.println();
						System.out.println();
						System.out.println("Answer the Given Question For Security Reason");
						System.out.println();
						System.out.println("1.What is your Birth place");
						System.out.println("2.What is the name of your first pet");
						System.out.println("3.What is your Favourite place");
						System.out.println("4.What is th ename of  your's father birth place");
						int sp=up.nextInt();
						switch(sp)
									{
									case 1: System.out.println();
											System.out.println();
											System.out.println("Enter Your Answer");
											String a1=up.nextLine();
											bp=up.nextLine();
											break;
									case 2: System.out.println();
											System.out.println();
											System.out.println("Enter Your Answer");
											String a2=up.nextLine();
											pn=up.nextLine();
											break;
									case 3: System.out.println();
											System.out.println();
											System.out.println("Enter Your Answer");
											String a3=up.nextLine();
											fp=up.nextLine();
											break;
									case 4: System.out.println();
											System.out.println();
											System.out.println("Enter Your Answer");
											String a4=up.nextLine();
											fb=up.nextLine();
											break;
									default:
											String sk5="Please choose correct no.from the given QUESTIONS";
														JOptionPane.showMessageDialog(null,sk5);
											System.exit(0);
									}
						System.out.println();
						System.out.println();
						System.out.println("Solve The Given Captcha To Complete Registration");
						System.out.println();
						System.out.println();
						System.out.println("\t\t\t10+20\t\t\t");
						int input=up.nextInt();
						if(input==30)
						{
							System.out.println();
						}
						else
						{
							String sk6="Wrong Captcha....Try Again";
														JOptionPane.showMessageDialog(null,sk6);
											System.exit(0);
						}
						File f=new File("C:\\Users\\SHIV\\Desktop\\Project\\EMPLOYEEFILES\\"+"CW"+uid+".txt");
						if(f.exists())
							{
								FileOutputStream fos=new FileOutputStream("C:\\Users\\SHIV\\Desktop\\Project\\EMPLOYEEFILES\\"+"CW"+uid+".txt");
								p.setProperty("USERNAME",uname);
								p.setProperty("DateOfJoining",doj);
								p.setProperty("PFNo.",pfn);
								p.setProperty("BirthPlace",bp);
								p.setProperty("PetName",pn);
								p.setProperty("FavouritePlace",fp);
								p.setProperty("FatherBirthPlace",fb);
								p.save(fos,"DATA INSERTED...");
							}
							
						else	
							{
								String sk7="USER DOES NOT EXIST...";
														JOptionPane.showMessageDialog(null,sk7);
											System.exit(0);
							}
						}
						catch(Exception e)
						{
							System.out.println(e.getMessage());
						}
						String sk8="DATA UPDATED SUCCESSFULLY....";
														JOptionPane.showMessageDialog(null,sk8);
						System.exit(0);
					}
					
					static void Change_PIN()
					{
						System.out.println();
						System.out.println();
						Scanner cp=new Scanner(System.in);
						System.out.println();
						System.out.println("Enter your OLD PIN:");
						String unewold=cp.nextLine();
						if(unewold.equals(upin))
						{
							
						}
						else
						{
							String sk9="OLD PASSWORD DOES NOT MATCH";
														JOptionPane.showMessageDialog(null,sk9);
							System.out.println();
							System.out.println();
							Change_PIN();
						}
						System.out.println("Enter your New Pin");
						String unew=cp.nextLine();
						char p1[]=unew.toCharArray();
						if(p1.length==4)
						{
							
						}
						else
						{
							String sk10="Password Must Be of 4-DIGIT";
														JOptionPane.showMessageDialog(null,sk10);
							System.out.println();
							System.out.println();
							Change_PIN();
						}
						System.out.println("Reenter Your New Password");
						upin=cp.nextLine();
						if(upin.equals(unew))
						{
							
						}
						else	
							{
										String sk11="NEW PASSWORD DOES NOT MATCH";
														JOptionPane.showMessageDialog(null,sk11);
						Change_PIN();
							}
							try
							{
							File f=new File("C:\\Users\\SHIV\\Desktop\\Project\\EMPLOYEEFILES\\"+"CW"+uid+".txt");
							if(f.exists())
							{
								FileOutputStream fos=new FileOutputStream("C:\\Users\\SHIV\\Desktop\\Project\\EMPLOYEEFILES\\"+"CW"+uid+".txt");
								p.setProperty("PIN",upin);
								p.save(fos,"DATA INSERTED...");
								System.out.println("PIN CHANGED SUCCESSFULLY");
							}
							}
							catch(Exception e)
							{
								System.out.println(e.getMessage());
							}
							System.exit(0);
						}
					
					static void ADD_Projects()
					{
						try{
							System.out.println("Enter The Project Id");
							Scanner op=new Scanner(System.in);
							String pid=op.nextLine();
							File f=new File("C:\\Users\\SHIV\\Desktop\\Project\\PROJECTRECORDS\\"+"PR"+uid+pid+".txt");
							if(!f.exists())
							{
							FileOutputStream fos=new FileOutputStream("C:\\Users\\SHIV\\Desktop\\Project\\PROJECTRECORDS\\"+"PR"+uid+pid+".txt");
							ObjectOutputStream oos=new ObjectOutputStream(fos);
							System.out.print("Enter the Name OF the Project:");
							String pname=op.nextLine();
							System.out.println();
							System.out.println("Enter the No. of Person's Working on the Project:");
							String pperson=op.nextLine();
							System.out.println();
							System.out.println("Enter the Amount which is assigned for Project:");
							String apn=op.nextLine();
							System.out.println();
							System.out.println("Enter the Starting date of Project");
							String spn=op.nextLine();
							System.out.println();
							System.out.println("Enter the Ending date of Project");
							String epn=op.nextLine();
							System.out.println();
							Employee2 e=new Employee2(pid,pname,pperson,apn,spn,epn);
							oos.writeObject(e);
							System.out.println("PROJECT ADDED SUCCESSFULLY");
							}
							else
							{
								String sk12="Project with this Id Already Exist...";
														JOptionPane.showMessageDialog(null,sk12);
							}
							System.out.println("Want to Add More Projects?");
							System.out.println("1.Yes");
							System.out.println("2.No");
							int ac=op.nextInt();
							if(ac==1)
							{
							 ADD_Projects();	
							}
							else	
							{
								if(ac==2)
								{
									System.exit(0);
								}
								else
								{
									String sk13="Wrong Input...Please Choose Correct Option..";
														JOptionPane.showMessageDialog(null,sk13);
								 ADD_Projects();
								
								}
							}
							}
						catch(Exception e)
						{
							System.out.println(e.getMessage());
						}
					}
					
					static void DELETE_PROJECT()
					{
						try{
							System.out.println("Enter The Project Id");
							Scanner pr=new Scanner(System.in);
							String pid=pr.nextLine();
							File f=new File("C:\\Users\\SHIV\\Desktop\\Project\\PROJECTRECORDS\\"+"PR"+uid+pid+".txt");
							if(f.exists())
							{
							f.delete();
							String sk14="Project Removed SuccessFully";
														JOptionPane.showMessageDialog(null,sk14);
							}
							else
							{
								String sk15="Project Does Not Exists";
														JOptionPane.showMessageDialog(null,sk15);
							}
							}
						catch(Exception e)
						{
							System.out.println(e.getMessage());
						}
					}
					
					static void VIEW_PROJECT()
					{
						try{
							System.out.println("Enter The Project Id for Which u want to view data");
							Scanner vp=new Scanner(System.in);
							String pid=vp.nextLine();
							File f=new File("C:\\Users\\SHIV\\Desktop\\Project\\PROJECTRECORDS\\"+"PR"+uid+pid+".txt");
							if(f.exists())
							{
							FileInputStream fis=new FileInputStream("C:\\Users\\SHIV\\Desktop\\Project\\PROJECTRECORDS\\"+"PR"+uid+pid+".txt");
							ObjectInputStream ovp=new ObjectInputStream(fis);
							Employee2 e1=(Employee2)ovp.readObject();
							System.out.println();
							System.out.println();
							System.out.println(" \t \t \t \t \t       ---------------------------------------------------------------------------------------------------");
							System.out.println("\t \t \t \t \t \t \t \t \t            PROJECT RECORD \t \t \t \t \t \t \t \t \t \t \t \t \t ");
							System.out.println(" \t \t \t \t \t       ---------------------------------------------------------------------------------------------------");
							System.out.println();
							System.out.println();
							System.out.print("\t \t \t \t \t        USERID\t         :      "+uid+"\t\t");
							System.out.print("\t\t  USERNAME         :\t"+p.getProperty("USERNAME"));
							System.out.println();
							System.out.println();
							System.out.print("\t \t \t \t \t \tDate of Joining  :\t"+p.getProperty("DateOfJoining"));
							System.out.print("\t\t\t  PF No.   \t   :\t"+p.getProperty("PFNo."));
							System.out.println();
							System.out.println();
							System.out.println(" \t \t \t \t \t       ---------------------------------------------------------------------------------------------------");
							System.out.println();
							System.out.println();
							System.out.println();
							System.out.println(" \t \t \t \t \t \tName Of the Project                   :"+"\t \t \t \t \t   "+e1.pname);
							System.out.println();
							System.out.println(" \t \t \t \t \t \tPersons Working On the Project        :"+"\t \t \t \t \t   "+e1.pperson);
							System.out.println();
							System.out.println(" \t \t \t \t \t \tTotal Amount Assigned To The Project  :"+"\t \t \t \t \t   "+e1.apn);
							System.out.println();
							System.out.println(" \t \t \t \t \t \tID of The Project                     :"+"\t \t \t \t \t   "+e1.pid);
							System.out.println();
							System.out.println(" \t \t \t \t \t \tStarting Date OF the Project          :"+"\t \t \t \t \t   "+e1.spn);
							System.out.println();
							System.out.println(" \t \t \t \t \t \tEnding Date OF the Project            :"+"\t \t \t \t \t   "+e1.epn);
							System.out.println();
							System.out.println(" \t \t \t \t\t       ---------------------------------------------------------------------------------------------------");
							}
							else
							{	
								System.out.println();
									String sk16="Project with this id does not exists...";
														JOptionPane.showMessageDialog(null,sk16);
								VIEW_PROJECT();
							}
							}
							catch(Exception e)
							{
								System.out.println(e.getMessage());
							}
					}
					
					static void forgot()
					{
						try	
						{
						Scanner fr=new Scanner(System.in);
						System.out.println("Enter your User Id");
						uid=fr.nextLine();
						System.out.println("Enter the Answer For Your Security Question");
						System.out.println();
						System.out.println();
						System.out.println("1.What is your Birth place");
						System.out.println("2.What is the name of your first pet");
						System.out.println("3.What is your Favourite place");
						System.out.println("4.What is th ename of  your's father birth place");
						System.out.println();
						System.out.println("Please Choose Option");
						int i=fr.nextInt();
						if(i==1)
						{
							
						}
						else
						{
							if(i==2)
							{
								
							}
							else
							{
								if(i==3)
								{
									
								}
								else
								{
									if(i==4)
									{
										
									}
									else
									{
												String sk17="Please Choose Correct Option";
														JOptionPane.showMessageDialog(null,sk17);
										System.exit(0);
									}
								}
							}
						}
						System.out.println("Enter the Answer");
						System.out.println();
						String fempty=fr.nextLine();
						String answer=fr.nextLine();
						System.out.println();
						System.out.println();
						System.out.println("\t\t\t10+4\t\t\t");
						int input=fr.nextInt();
						if(input==14)
						{
							System.out.println();
						}
						else
						{
								String sk18="Wrong Captcha....Try Again";
														JOptionPane.showMessageDialog(null,sk18);
							System.exit(0);
						}
						File f1=new File("C:\\Users\\SHIV\\Desktop\\Project\\EMPLOYEEFILES\\"+"CW"+uid+".txt");
						if(f1.exists())
						{
							FileInputStream fis=new FileInputStream("C:\\Users\\SHIV\\Desktop\\Project\\EMPLOYEEFILES\\"+"CW"+uid+".txt");
							p.load(fis);
							if(p.getProperty("BirthPlace").equals(answer) || p.getProperty("PetName").equals(answer)||p.getProperty("FavouritePlace").equals(answer) ||p.getProperty("FatherBirthPlace").equals(answer))
							{
								System.out.println(" \t \t \t \t \t       ---------------------------------------------------------------------------------------------------");
								System.out.println("\t \t \t \t \t \t \t \t \t            WELCOME"+"\t"+uid+" \t \t \t \t \t \t \t \t \t \t \t \t \t ");
								System.out.println(" \t \t \t \t \t       ---------------------------------------------------------------------------------------------------");
								System.out.println();
								System.out.println();
								System.out.println("\t \t \t \t \t \t \t \t \t         USERID IS:-"+"\t"+p.getProperty("USERID")+" \t \t \t \t \t \t \t \t \t \t \t \t \t ");
								System.out.println();
								System.out.println("\t \t \t \t \t \t \t \t \t         USER PIN :-"+"\t"+p.getProperty("PIN")+" \t \t \t \t \t \t \t \t \t \t \t \t \t ");
								System.out.println();
								System.out.println(" \t \t \t \t \t       ---------------------------------------------------------------------------------------------------");
								System.exit(0);
							}
							else
							{
									String sk19="Wrong Answer";
														JOptionPane.showMessageDialog(null,sk19);
								System.exit(0);
							}
						}
						else
							{
								String sk20="USER WITH THIS ID DOES NOT EXISTS.....";
														JOptionPane.showMessageDialog(null,sk20);
							System.exit(0);
							
							}
						}
						catch(Exception e)
						{
							System.out.println(e.getMessage());
						}
	
					}
									
					static void UPDATE_CLIENT()
					{
						try{
							System.out.println("Enter The Client Id for Which u want to update data");
							Scanner uc=new Scanner(System.in);
							String cid=uc.nextLine();
							File f=new File("C:\\Users\\SHIV\\Desktop\\Project\\CLIENTRECORDS\\"+"CR"+uid+cid+".txt");
							if(f.exists())
							{
							FileInputStream fis=new FileInputStream("C:\\Users\\SHIV\\Desktop\\Project\\CLIENTRECORDS\\"+"CR"+uid+cid+".txt");
							ObjectInputStream ois=new ObjectInputStream(fis);
							Employee1 e1=(Employee1)ois.readObject();
							System.out.println("\t \t \t \t \t \t \t \t \t            Client Old Details \t \t \t \t \t \t \t \t \t \t \t \t \t ");
							System.out.println();
							System.out.println();
							System.out.println(" \t \t \t \t \t       ---------------------------------------------------------------------------------------------------");
							System.out.println("\t \t \t \t \t \t \t \t \t            CLIENT RECORD \t \t \t \t \t \t \t \t \t \t \t \t \t ");
							System.out.println(" \t \t \t \t \t       ---------------------------------------------------------------------------------------------------");
							System.out.println();
							System.out.println();
							System.out.print("\t \t \t \t \t        USERID\t         :      "+uid+"\t\t");
							System.out.print("\t\t  USERNAME         :\t"+p.getProperty("USERNAME"));
							System.out.println();
							System.out.println();
							System.out.print("\t \t \t \t \t \tDate of Joining  :\t"+p.getProperty("DateOfJoining"));
							System.out.print("\t\t\t  PF No.   \t   :\t"+p.getProperty("PFNo."));
							System.out.println();
							System.out.println();
							System.out.println(" \t \t \t \t \t       ---------------------------------------------------------------------------------------------------");
							System.out.println();
							System.out.println();
							System.out.println();
							System.out.println(" \t \t \t \t \t \tName Of the Client  :"+"\t \t \t \t \t   "+e1.cname);
							System.out.println();
							System.out.println(" \t \t \t \t \t \tUSerID Of the Client:"+"\t \t \t \t \t   "+e1.cid);
							System.out.println();
							System.out.println(" \t \t \t \t \t \tAdddress of Client  :"+"\t \t \t \t \t   "+e1.cadd);
							System.out.println();
							System.out.println(" \t \t \t \t \t \tPhone No. of Client :"+"\t \t \t \t \t   "+e1.cpn);
							System.out.println();
							System.out.println(" \t \t \t \t \t \tEmail-Id of Client  :"+"\t \t \t \t \t   "+e1.cei);
							System.out.println();
							System.out.println(" \t \t \t \t\t       ---------------------------------------------------------------------------------------------------");
							
							FileOutputStream fos=new FileOutputStream("C:\\Users\\SHIV\\Desktop\\Project\\CLIENTRECORDS\\"+"CR"+uid+cid+".txt");
							ObjectOutputStream oos=new ObjectOutputStream(fos);
							System.out.print("Enter the Name OF the Client:");
							String cname=uc.nextLine();
							System.out.println();
							System.out.println("Enter the Address Of the Client:");
							String cadd=uc.nextLine();
							System.out.println();
							System.out.println("Enter te Client Phone No.");
							String cpn=uc.nextLine();
							System.out.println("Enter the Email ID ");
							String cei=uc.nextLine();
							System.out.println();
							Employee1 e=new Employee1(cname,cid,cadd,cpn,cei);
							oos.writeObject(e);
							System.out.println("CLIENT DETAILS UPDATED SUCCESSFULLY");
							System.out.println();
							System.out.println();
							FileInputStream frs=new FileInputStream("C:\\Users\\SHIV\\Desktop\\Project\\CLIENTRECORDS\\"+"CR"+uid+cid+".txt");
							ObjectInputStream ors=new ObjectInputStream(frs);
							Employee1 e2=(Employee1)ors.readObject();
							System.out.println("\t \t \t \t \t \t \t \t \t            Client New Details \t \t \t \t \t \t \t \t \t \t \t \t \t ");
							System.out.println();
							System.out.println();
							System.out.println(" \t \t \t \t \t       ---------------------------------------------------------------------------------------------------");
							System.out.println("\t \t \t \t \t \t \t \t \t            CLIENT RECORD \t \t \t \t \t \t \t \t \t \t \t \t \t ");
							System.out.println(" \t \t \t \t \t       ---------------------------------------------------------------------------------------------------");
							System.out.println();
							System.out.println();
							System.out.print("\t \t \t \t \t        USERID\t         :      "+uid+"\t\t");
							System.out.print("\t\t  USERNAME         :\t"+p.getProperty("USERNAME"));
							System.out.println();
							System.out.println();
							System.out.print("\t \t \t \t \t \tDate of Joining  :\t"+p.getProperty("DateOfJoining"));
							System.out.print("\t\t\t  PF No.   \t   :\t"+p.getProperty("PFNo."));
							System.out.println();
							System.out.println();
							System.out.println();
							System.out.println(" \t \t \t \t \t       ---------------------------------------------------------------------------------------------------");
							System.out.println();
							System.out.println();
							System.out.println();
							System.out.println(" \t \t \t \t \t \tName Of the Client  :"+"\t \t \t \t \t   "+e2.cname);
							System.out.println();
							System.out.println(" \t \t \t \t \t \tUSerID Of the Client:"+"\t \t \t \t \t   "+e2.cid);
							System.out.println();
							System.out.println(" \t \t \t \t \t \tAdddress of Client  :"+"\t \t \t \t \t   "+e2.cadd);
							System.out.println();
							System.out.println(" \t \t \t \t \t \tPhone No. of Client :"+"\t \t \t \t \t   "+e2.cpn);
							System.out.println();
							System.out.println(" \t \t \t \t \t \tEmail-Id of Client  :"+"\t \t \t \t \t   "+e2.cei);
							System.out.println();
							System.out.println(" \t \t \t \t\t       ---------------------------------------------------------------------------------------------------");
							}
							else
							{								String sk21="Client with this id does not exists...";
														JOptionPane.showMessageDialog(null,sk21);
								UPDATE_CLIENT();
							}
						}
							catch(Exception e)
							{
								System.out.println(e.getMessage());
							}
					}
					
					static void VIEW_CLIENT()
					{
						try{
							System.out.println("Enter The Client Id for Which u want to view data");
							Scanner vc=new Scanner(System.in);
							String cid=vc.nextLine();
							File f=new File("C:\\Users\\SHIV\\Desktop\\Project\\CLIENTRECORDS\\"+"CR"+uid+cid+".txt");
							if(f.exists())
							{
							FileInputStream fis=new FileInputStream("C:\\Users\\SHIV\\Desktop\\Project\\CLIENTRECORDS\\"+"CR"+uid+cid+".txt");
							ObjectInputStream ovc=new ObjectInputStream(fis);
							Employee1 e3=(Employee1)ovc.readObject();
							System.out.println("\t \t \t \t \t \t \t \t \t            Client Old Details \t \t \t \t \t \t \t \t \t \t \t \t \t ");
							System.out.println();
							System.out.println();
							System.out.println(" \t \t \t \t \t       ---------------------------------------------------------------------------------------------------");
							System.out.println("\t \t \t \t \t \t \t \t \t            CLIENT RECORD \t \t \t \t \t \t \t \t \t \t \t \t \t ");
							System.out.println(" \t \t \t \t \t       ---------------------------------------------------------------------------------------------------");
							System.out.println();
							System.out.println();
							System.out.print("\t \t \t \t \t        USERID\t         :      "+uid+"\t\t");
							System.out.print("\t\t  USERNAME         :\t"+p.getProperty("USERNAME"));
							System.out.println();
							System.out.println();
							System.out.print("\t \t \t \t \t \tDate of Joining  :\t"+p.getProperty("DateOfJoining"));
							System.out.print("\t\t\t  PF No.   \t   :\t"+p.getProperty("PFNo."));
							System.out.println();
							System.out.println();
							System.out.println(" \t \t \t \t \t       ---------------------------------------------------------------------------------------------------");
							System.out.println();
							System.out.println();
							System.out.println();
							System.out.println(" \t \t \t \t \t \tName Of the Client  :"+"\t \t \t \t \t   "+e3.cname);
							System.out.println();
							System.out.println(" \t \t \t \t \t \tUSerID Of the Client:"+"\t \t \t \t \t   "+e3.cid);
							System.out.println();
							System.out.println(" \t \t \t \t \t \tAdddress of Client  :"+"\t \t \t \t \t   "+e3.cadd);
							System.out.println();
							System.out.println(" \t \t \t \t \t \tPhone No. of Client :"+"\t \t \t \t \t   "+e3.cpn);
							System.out.println();
							System.out.println(" \t \t \t \t \t \tEmail-Id of Client  :"+"\t \t \t \t \t   "+e3.cei);
							System.out.println();
							System.out.println(" \t \t \t \t\t       ---------------------------------------------------------------------------------------------------");
							}
							else
							{
									String sk22="Client with this id does not exists...";
														JOptionPane.showMessageDialog(null,sk22);
								VIEW_CLIENT();
							}
							}
							catch(Exception e)
							{
								System.out.println(e.getMessage());
							}
					}
					
					static void DELETE_CLIENT()
					{
						try{
							System.out.println("Enter The Client Id");
							Scanner cr=new Scanner(System.in);
							String cid=cr.nextLine();
							File f=new File("C:\\Users\\SHIV\\Desktop\\Project\\CLIENTRECORDS\\"+"CR"+uid+cid+".txt");
							if(f.exists())
							{
							f.delete();
							String sk23="Client Removed SuccessFully";
														JOptionPane.showMessageDialog(null,sk23);
							}
							else
							{
								String sk24="Client Does Not Exists";
														JOptionPane.showMessageDialog(null,sk24);
							}
							}
						catch(Exception e)
						{
							System.out.println(e.getMessage());
						}
					}
					
					static void signup()
					{	
						
						try
						{
						System.out.println();
						Scanner su=new Scanner(System.in);
						System.out.print("Enter your Full Name:");
						uname=su.nextLine();
						System.out.println();
						System.out.print("Please Select Your UserId:");
						uid=su.nextLine();
						System.out.println();
						System.out.print("Please Select Your 4-DIGIT PIN:");
						upin=su.nextLine();
						char c[]=upin.toCharArray();
						if(c.length==4)
						{	
						}
						else
						{
							String sk25="Enter Valid PIN";
														JOptionPane.showMessageDialog(null,sk25);
						signup();
						}
						System.out.println();
						System.out.print("Please Enter your Date of Joining:");
						doj=su.nextLine();
						System.out.println();
						System.out.print("Please Enter Your Pf No.:");
						pfn=su.nextLine();
						System.out.println();
						System.out.println();
						System.out.println("Answer the Given Question For Security Reason");
						System.out.println();
						System.out.println("1.What is your Birth place");
						System.out.println("2.What is the name of your first pet");
						System.out.println("3.What is your Favourite place");
						System.out.println("4.What is th ename of  your's father birth place");
						int sq=su.nextInt();
						switch(sq)
									{
									case 1: System.out.println();
											System.out.println();
											System.out.println("Enter Your Answer");
											String a1=su.nextLine();
											bp=su.nextLine();
											break;
									case 2: System.out.println();
											System.out.println();
											System.out.println("Enter Your Answer");
											String a2=su.nextLine();
											pn=su.nextLine();
											break;
									case 3: System.out.println();
											System.out.println();
											System.out.println("Enter Your Answer");
											String a3=su.nextLine();
											fp=su.nextLine();
											break;
									case 4: System.out.println();
											System.out.println();
											System.out.println("Enter Your Answer");
											String a4=su.nextLine();
											fb=su.nextLine();
											break;
									default:
											String sk26="Please choose correct no.from the given QUESTIONS";
														JOptionPane.showMessageDialog(null,sk26);
											System.exit(0);
									}
						System.out.println();
						System.out.println();
						System.out.println("Solve The Given Captcha To Complete Registration");
						System.out.println();
						System.out.println();
						System.out.println("\t\t\t3+4\t\t\t");
						int input=su.nextInt();
						if(input==7)
						{
							System.out.println();
						}
						else
						{
							String sk27="Please choose correct no.from the given QUESTIONS";
														JOptionPane.showMessageDialog(null,sk27);
							System.exit(0);
						}
						File f=new File("C:\\Users\\SHIV\\Desktop\\Project\\EMPLOYEEFILES\\"+"CW"+uid+".txt");
						if(!f.exists())
							{
								FileOutputStream fos=new FileOutputStream("C:\\Users\\SHIV\\Desktop\\Project\\EMPLOYEEFILES\\"+"CW"+uid+".txt");
								p.setProperty("USERNAME",uname);
								p.setProperty("USERID",uid);
								p.setProperty("PIN",upin);
								p.setProperty("DateOfJoining",doj);
								p.setProperty("PFNo.",pfn);
								p.setProperty("BirthPlace",bp);
								p.setProperty("PetName",pn);
								p.setProperty("FavouritePlace",fp);
								p.setProperty("FatherBirthPlace",fb);
								p.save(fos,"DATA INSERTED...");
							}
							
						else	
							{
								String sk27="USER ALREADY EXIST...";
														JOptionPane.showMessageDialog(null,sk27);
						System.exit(0);
							}
						}
						catch(Exception e)
						{
							System.out.println(e.getMessage());
						}
						String sk28="DATA ENTERED SUCCESSFULLY....";
														JOptionPane.showMessageDialog(null,sk28);
						System.exit(0);
					}

	
					
					static void signin()
					{	
						try	
						{
						Scanner si=new Scanner(System.in);
						System.out.println("Enter your User Id");
						uid=si.nextLine();
						System.out.println("Enter your 4-DIGIT Pin");
						upin=si.nextLine();
						
						File f1=new File("C:\\Users\\SHIV\\Desktop\\Project\\EMPLOYEEFILES\\"+"CW"+uid+".txt");
						if(f1.exists())
						{
							FileInputStream fis=new FileInputStream("C:\\Users\\SHIV\\Desktop\\Project\\EMPLOYEEFILES\\"+"CW"+uid+".txt");
							p.load(fis);
							if(p.getProperty("USERID").equals(uid) && p.getProperty("PIN").equals(upin))
							{
								System.out.println("\t \t \t \t \t \t \t \t \t            WELCOME"+"\t"+uid+" \t \t \t \t \t \t \t \t \t \t \t \t \t ");
								System.out.println();
								System.out.println();
								System.out.println("\t \t \t \t \t \t \t \t \t            NAME"+"\t"+p.getProperty("USERNAME")+" \t \t \t \t \t \t \t \t \t \t \t \t \t ");
								System.out.println();
							}
							else
							{
								String sk29="Wrong UserName OR PIN";
														JOptionPane.showMessageDialog(null,sk29);
								System.exit(0);
							}
						}
						else
							{
								String sk30="USER DOES NOT EXISTS.....";
														JOptionPane.showMessageDialog(null,sk30);
							System.exit(0);
							
							}
						}
						catch(Exception e)
						{
							System.out.println(e.getMessage());
						}
					}
					
					
					static void Apply_For_Leave()
						{
						Scanner k=new Scanner(System.in);
						System.out.println("\t \t \t \t \t \t \t \t \t             LEAVE APPLICATION \t \t \t \t \t \t \t \t \t \t \t \t \t ");
						System.out.println("1.Submit New Leave");
						System.out.print("2.Review Your Previous Application:");
						System.out.println();
						int start=k.nextInt();
						switch(start)
										{
										case 1: New_leave();
												break;
										case 2: Review();
												break;
										default:
													String sk31="Choose Correct option...";
														JOptionPane.showMessageDialog(null,sk31);
												System.exit(0);
										}
						}
							
						static void New_leave()
						{
						Scanner m=new Scanner(System.in);
						System.out.println("How many Leaves You Want?");
						int a=m.nextInt();
						System.out.println("Any Leave Taken In the Current Month?");
						int b=m.nextInt();
						int c=a+b;
						if(c>=3)
							{
							System.out.println();
							System.out.println("YOU HAD USED YOUR FREE LEAVES...YOU WILL BE CHARGED FOR LEAVES");
							System.out.println();
							System.out.println();
							}

						System.out.println("Do you want to apply for LEAVES?");
						System.out.println();
						System.out.println("1.YES");
						System.out.println("2.NO");
						int d=m.nextInt();
						System.out.println();
						if(d==1)
							{
							System.out.println("\t \t \t \t \t \t \t \t \t             FILL APPLICATION \t \t \t \t \t \t \t \t \t \t \t \t \t ");
							}
						else 
								if(d==2)
									{
										String sk31="Thank You...! Please Login Again to chooose Other Options";
														JOptionPane.showMessageDialog(null,sk31);
									System.exit(0);
									}
								else	
									{
										String sk32="Choose Correct Option..PLease Login Again";
														JOptionPane.showMessageDialog(null,sk32);
									System.exit(0);
									}
							try
								{	
									String fempty=m.nextLine();
									System.out.println("Enter the Month For which you want the leave:");
									String umonth=m.nextLine();
									System.out.println("No. of Leaves:");
									String uleave=m.nextLine();
									Integer i=Integer.valueOf(uleave);
									int z=i.intValue();
									if(z==a)
									{
									}
									else
									{
											String sk33="Please Enter the Same No. Of Leave Apllied Before";
														JOptionPane.showMessageDialog(null,sk33);
										New_leave();
									}
									System.out.println("Date (FROM TO FROM)");
									String udate=m.nextLine();
									System.out.println("Reason for the Leave");
									String ureason=m.nextLine();
									File f=new File("C:\\Users\\SHIV\\Desktop\\Project\\EMPLOYEELEAVES\\"+"LEAVE"+uid+umonth+".txt");
									if(!f.exists())
									{
									FileOutputStream fos=new FileOutputStream("C:\\Users\\SHIV\\Desktop\\Project\\EMPLOYEELEAVES\\"+"LEAVE"+uid+umonth+".txt");	
									p.setProperty("MONTH",umonth);
									p.setProperty("LEAVES",uleave);
									p.setProperty("DATE",udate);
									p.setProperty("REASON",ureason);
									p.save(fos,"DATA INSERTED...");
											String sk34="APLLICATION SUBMITTED SUCCESSFULLY....";
														JOptionPane.showMessageDialog(null,sk34);
									}
									else	
									{
										String sk35="You had already requested for the Leave..Please check its status";
														JOptionPane.showMessageDialog(null,sk35);
										Apply_For_Leave();
									}
								}
								catch(Exception e)
								{
									System.out.println(e.getMessage());
								}
									
						}
						
					static void Review()
					{	
						try
						{
						Scanner re=new Scanner(System.in);
						System.out.println("Enter your User Id");
						String uid=re.nextLine();
						System.out.println("Enter the Month");
						String umonth=re.nextLine();
						
						File f1=new File("C:\\Users\\SHIV\\Desktop\\Project\\EMPLOYEELEAVES\\"+"LEAVE"+uid+umonth+".txt");
						if(f1.exists())
						{
						FileInputStream fis=new FileInputStream("C:\\Users\\SHIV\\Desktop\\Project\\EMPLOYEELEAVES\\"+"LEAVE"+uid+umonth+".txt");
							p.load(fis);
							if(p.getProperty("MONTH").equals(umonth))
							{
						System.out.println(" \t \t \t \t \t       ------------------------------------------------------------------------------------------------------------");
						System.out.println("\t \t \t \t \t \t \t \t \t            LEAVE APPLICATION ("+umonth+") \t \t \t \t \t \t \t \t \t \t \t \t \t ");
						System.out.println(" \t \t \t \t \t       ------------------------------------------------------------------------------------------------------------");
						System.out.println();
						System.out.println();
						System.out.print("\t \t \t \t \t        USERID\t         :      "+uid+"\t\t");
						System.out.print("\t\t  USERNAME         :\t"+p.getProperty("USERNAME"));
						System.out.println();
						System.out.println();
						System.out.print("\t \t \t \t \t \tDate of Joining  :\t"+p.getProperty("DateOfJoining"));
						System.out.print("\t\t\t  PF No.   \t   :\t"+p.getProperty("PFNo."));
						System.out.println();
						System.out.println();
						System.out.println();
						System.out.println("\t \t \t \t \t \tNo.of Leaves     :"+"\t \t \t \t \t            "+p.getProperty("LEAVES"));
						System.out.println();
						System.out.println("\t \t \t \t \t \tDate From To From:"+"\t \t \t \t \t            "+p.getProperty("DATE"));
						System.out.println();
						System.out.println("\t \t \t \t \t \tReason Of Leave  :"+"\t \t \t \t \t            "+p.getProperty("REASON"));
						System.out.println();
						System.out.println(" \t \t \t \t \t       ------------------------------------------------------------------------------------------------------------");
							}
							else
							{
								String sk36="Not Applied For Leaves Yet..";
														JOptionPane.showMessageDialog(null,sk36);
								Apply_For_Leave();
							}
						}
						else
						{
							String sk37="NO APPLICATION FOUND";
														JOptionPane.showMessageDialog(null,sk37);
							System.exit(0);
						}
						}
						catch(Exception e)
						{
						System.out.println(e.getMessage());
						}
						
					}
					
					static void ADD_CLIENT()
					{
						try{
							System.out.println("Enter The Client Id");
							Scanner cr=new Scanner(System.in);
							String cid=cr.nextLine();
							File f=new File("C:\\Users\\SHIV\\Desktop\\Project\\CLIENTRECORDS\\"+"CR"+uid+cid+".txt");
							if(!f.exists())
							{
							FileOutputStream fos=new FileOutputStream("C:\\Users\\SHIV\\Desktop\\Project\\CLIENTRECORDS\\"+"CR"+uid+cid+".txt");
							ObjectOutputStream oos=new ObjectOutputStream(fos);
							System.out.print("Enter the Name OF the Client:");
							String cname=cr.nextLine();
							System.out.println();
							System.out.println("Enter the Address Of the Client:");
							String cadd=cr.nextLine();
							System.out.println();
							System.out.println("Enter te Client Phone No.");
							String cpn=cr.nextLine();
							System.out.println();
							System.out.println("Enter the E-Mail ID of Client");
							String cei=cr.nextLine();
							Employee1 e=new Employee1(cname,cid,cadd,cpn,cei);
							oos.writeObject(e);
							String sk37="CLIENT ADDED SUCCESSFULLY";
														JOptionPane.showMessageDialog(null,sk37);
							}
							else
							{
														String sk38="Client With This User Id Already Exist...";
														JOptionPane.showMessageDialog(null,sk38);	
							}
							System.out.println("Want to Add More Clients?");
							System.out.println("1.Yes");
							System.out.println("2.No");
							int ac=cr.nextInt();
							if(ac==1)
							{
							 ADD_CLIENT();	
							}
							else	
							{
								if(ac==2)
								{
									System.exit(0);
								}
								else
								{
									String sk39="Wrong Input...Please Choose Correct Option..";
														JOptionPane.showMessageDialog(null,sk39);		
								 ADD_CLIENT();
								
								}
							}
							}
						catch(Exception e)
						{
							System.out.println(e.getMessage());
						}
					}
							
					static void Employee_Payslip()
						{
						Scanner l=new Scanner(System.in);
						System.out.println("Enter the month for which you want to generate PAY-SLIP");
						String ps=l.nextLine();
						System.out.println("Enter the Following Details for the current Month");
						System.out.println();
						System.out.println();
						System.out.print("Basic:");
						int basic=l.nextInt();
						System.out.print("No. of Leaves taken:");
						int leaves=l.nextInt();
						float hra=((43.34f*basic)/100);
						float conveyance=((6.67f*basic)/100);
						float sa=((10*basic)/100);
						float lta=((16.66f*basic)/100);
						System.out.println();
						float tgs=basic+hra+conveyance+sa+lta;
						float pf=((12*basic)/100);
						float tds=((10*basic)/100);
						float others=((tgs/30)*leaves);
						float tns=(tgs-others-pf-tds);
						
						
						System.out.println();
						System.out.println();
						System.out.println();
						System.out.println(" \t \t \t \t \t       -------------------------------------------------------------------------------------------------------");
						System.out.println("\t \t \t \t \t \t \t \t \t              PAY-SLIP ("+ps+") \t \t \t \t \t \t \t \t \t \t \t \t \t ");
						System.out.println(" \t \t \t \t \t       -------------------------------------------------------------------------------------------------------");
						System.out.println();
						System.out.println();
						System.out.print("\t \t \t \t \t        USERID\t         :      "+uid+"\t\t");
						System.out.print("\t\t  USERNAME         :\t"+p.getProperty("USERNAME"));
						System.out.println();
						System.out.println();
						System.out.print("\t \t \t \t \t \tDate of Joining  :\t"+p.getProperty("DateOfJoining"));
						System.out.print("\t\t\t  PF No.   \t   :\t"+p.getProperty("PFNo."));
						System.out.println();
						System.out.println();
						System.out.println("\t \t \t \t \t \t \tBasic:"+"\t \t \t \t \t\t\t\t      "+basic);
						System.out.println("\t \t \t \t \t \t \tHRA:"+"\t \t \t \t \t\t\t\t     "+hra);
						System.out.println("\t \t \t \t \t \t \tConveyance:"+"\t \t \t \t \t\t\t      "+conveyance);
						System.out.println("\t \t \t \t \t \t \tSA:"+"\t \t \t \t \t\t\t\t     "+sa);
						System.out.println("\t \t \t \t \t \t \tLTA:"+"\t \t \t \t \t\t\t\t     "+lta);
						System.out.println();
						System.out.println(" \t \t \t \t \t       -------------------------------------------------------------------------------------------------------");
						System.out.println("\t \t \t \t \t \t \tTotal Gross Salary:"+"\t \t \t \t \t\t    "+tgs);
						System.out.println(" \t \t \t \t \t       -------------------------------------------------------------------------------------------------------");
						System.out.println();
						System.out.println("\t \t \t \t \t \t \tTotal Deductions:-");
						System.out.println();
						System.out.println("\t \t \t \t \t \t \tPF:"+"\t \t \t \t \t\t\t\t     "+pf);
						System.out.println("\t \t \t \t \t \t \tTDS:"+"\t \t \t \t \t\t\t\t     "+tds);
						System.out.println("\t \t \t \t \t \t \tOthers:"+"\t \t \t \t \t\t\t\t     "+others);
						System.out.println();
						System.out.println(" \t \t \t \t \t       -------------------------------------------------------------------------------------------------------");
						System.out.println("\t \t \t \t \t \t \tTotal Net Salary:"+"\t \t \t \t \t\t    "+tns);
						System.out.println(" \t \t \t \t \t       -------------------------------------------------------------------------------------------------------");
						
						}
			}

	
	
			