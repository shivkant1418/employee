import java.io.Serializable;
class Employee2 implements Serializable
							{
							
							String pid;
							String pname;
							String pperson;
							String apn;
							String spn;
							String epn;
								Employee2(String pid,String pname,String pperson,String apn,String spn,String epn)
								
								{
									this.pid=pid;
									this.pname=pname;
									this.pperson=pperson;
									this.apn=apn;
									this.spn=spn;
									this.epn=epn;
									
								}
							}
