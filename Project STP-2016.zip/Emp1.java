import java.io.Serializable;
class Employee1 implements Serializable
							{

							String cname;
							String cid;
							String cadd;
							String cpn;
							String cei;
								Employee1(String cname,String cid,String cadd,String cpn,String cei)
								
								{
									this.cname=cname;
									this.cid=cid;
									this.cadd=cadd;
									this.cpn=cpn;
									this.cei=cei;
									
								}
							}
